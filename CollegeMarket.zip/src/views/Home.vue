<template lang="">
    <div>
        <Alert alert_type="info" alert_text="Тестовый алерт информации" />
        <Alert alert_type="error" alert_text="Тестовый алерт ошибки" />
        <Alert alert_type="warning" alert_text="Тестовый алерт предупреждения" />
        <Alert alert_type="success" alert_text="Тестовый алерт упеха" />
    </div>
</template>
<script setup>
    import Alert from '../components/UI/Alert.vue';
</script>
<style scoped>
</style>